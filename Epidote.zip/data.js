// Sample data for the Epidote prototype.
// One shape per entity. Meetings reference tasks and docs by id so we never
// duplicate the source of truth.

window.EpidoteData = (() => {
  const now = new Date('2026-04-22T14:30:00');

  const people = {
    sj: { id: 'sj', initials: 'SJ', name: 'Sarah J.', accent: 'var(--primary)' },
    dc: { id: 'dc', initials: 'DC', name: 'David C.', accent: 'var(--accent-purple)' },
    ml: { id: 'ml', initials: 'ML', name: 'Marcus L.', accent: 'var(--accent-amber)' },
    rk: { id: 'rk', initials: 'RK', name: 'Rachel K.', accent: 'var(--text-dim)' },
    pl: { id: 'pl', initials: 'PL', name: 'Priya L.', accent: 'var(--accent-purple)' },
    me: { id: 'me', initials: 'MA', name: 'You', accent: 'var(--primary)' },
  };

  // Tasks — single source of truth.
  const tasks = [
    {
      id: 'TSK-092',
      title: 'Determine optimal chunking strategy for vector embeddings',
      status: 'active',
      owner: 'me',
      due: 'in 4 days',
      dueSoon: true,
      meetingId: 'mtg-live',
      docs: ['doc-embed-arch', 'doc-chunk-bench'],
      description:
        'Trade-off between recall and token budget. Run side-by-side eval on the meetings corpus with 256 / 512 / 1024-token windows and 0 / 64 / 128-token overlap. Land on a default before the RAG cutover.',
      proposalId: 'prop-chunking',
    },
    {
      id: 'TSK-104',
      title: 'Review Redis caching strategy for high-frequency reads',
      status: 'triage',
      owner: 'dc',
      due: 'in 9 days',
      dueSoon: false,
      meetingId: 'mtg-q3arch',
      docs: ['doc-caching-rfc'],
      description:
        'Cache hit rate on hot keys is plateauing around 78%. Compare current per-request lookup against a write-through layer with TTL bucketing, and call out memory ceiling implications.',
      proposalId: 'prop-caching-owner',
    },
    {
      id: 'TSK-108',
      title: 'Update IAM roles for new microservices deployment',
      status: 'triage',
      owner: 'rk',
      due: null,
      dueSoon: false,
      meetingId: null,
      docs: [],
      description: 'Three new services (graph-indexer, vault-search, transcript-rag) need scoped roles with least-privilege defaults.',
    },
    {
      id: 'TSK-112',
      title: 'Spec retry/backoff policy for ingest workers',
      status: 'triage',
      owner: 'ml',
      due: 'in 14 days',
      dueSoon: false,
      meetingId: 'mtg-pipeline',
      docs: [],
      description: null,
    },
    {
      id: 'TSK-096',
      title: 'Profile cold-start latency on inference workers',
      status: 'active',
      owner: 'dc',
      due: null,
      dueSoon: false,
      meetingId: 'mtg-latency',
      docs: [],
      description: 'First-token latency spikes after autoscale-down events. Capture flame graphs from the next idle cycle.',
    },
    {
      id: 'TSK-088',
      title: 'Migrate legacy logging to Datadog cluster',
      status: 'blocked',
      owner: 'rk',
      due: 'tomorrow',
      dueSoon: true,
      meetingId: 'mtg-observability',
      docs: [],
      description:
        'Agent rollout staged behind security review. Once the policy bundle is signed off, switch the legacy syslog forwarder to the Datadog agent in two phases.',
      blockedNote: 'Awaiting security approval for agent deployment.',
    },
    {
      id: 'TSK-118',
      title: 'Publish Q3 roadmap one-pager',
      status: 'active',
      owner: 'pl',
      due: 'in 2 days',
      dueSoon: true,
      meetingId: 'mtg-q3roadmap',
      docs: ['doc-q3-roadmap'],
      proposalId: 'prop-summary',
    },
  ];

  // Vault docs — the actual knowledge base.
  const docs = [
    { id: 'doc-embed-arch', name: 'Embedding Architecture', path: 'Architecture/Embedding Architecture.md', folder: 'Architecture', updated: '2d ago', links: ['doc-chunk-bench', 'doc-caching-rfc'] },
    { id: 'doc-chunk-bench', name: 'Chunking Benchmarks', path: 'Architecture/Chunking Benchmarks.md', folder: 'Architecture', updated: '3d ago', links: ['doc-embed-arch'] },
    { id: 'doc-caching-rfc', name: 'Caching RFC v2', path: 'Architecture/Caching RFC v2.md', folder: 'Architecture', updated: '1w ago', links: [] },
    { id: 'doc-migration', name: 'Migration Manifesto v1', path: 'Architecture/Migration Manifesto v1.md', folder: 'Architecture', updated: 'just now', links: ['doc-embed-arch'] },
    { id: 'doc-q3-roadmap', name: 'Q3 Roadmap v0', path: 'Planning/Q3 Roadmap v0.md', folder: 'Planning', updated: '4h ago', links: [] },
    { id: 'doc-pentest', name: 'Pentest Q3 Findings', path: 'Security/Pentest Q3 Findings.md', folder: 'Security', updated: '2d ago', links: [] },
  ];

  // Meetings — unified. State drives the detail view.
  const meetings = [
    {
      id: 'mtg-live',
      title: 'System Architecture Sync',
      state: 'live',
      project: 'Project Alpha · Engineering',
      elapsed: '01:24:03',
      date: 'Now',
      dateLong: 'Apr 22, 2026',
      durationMin: 84,
      participants: ['sj', 'dc', 'ml', 'rk', 'me'],
      preview: 'Discussion on migrating legacy microservices to the new event-driven pipeline.',
      taskIds: ['TSK-092'],
      docIds: [],
      proposalIds: ['prop-chunking', 'prop-extract'],
      pinned: true,
    },
    {
      id: 'mtg-q3roadmap',
      title: 'Q3 Roadmap Planning',
      state: 'processing',
      project: 'Product',
      date: '6h ago',
      dateLong: 'Apr 22, 2026',
      durationMin: 66,
      participants: ['sj', 'pl', 'dc'],
      preview: 'Priority alignment for upcoming core product updates and AI integrations.',
      taskIds: ['TSK-118'],
      docIds: ['doc-q3-roadmap'],
      proposalIds: ['prop-roadmap'],
      processingStep: 'Generating agenda',
      processingPct: 72,
    },
    {
      id: 'mtg-q3arch',
      title: 'Q3 Data Architecture',
      state: 'archived',
      project: 'Project Alpha · Engineering',
      date: '2d ago',
      dateLong: 'Apr 20, 2026',
      durationMin: 54,
      participants: ['sj', 'dc', 'ml'],
      preview: 'Caching layer ownership, TSK-104 scope, and write-through vs per-request.',
      taskIds: ['TSK-104'],
      docIds: ['doc-caching-rfc'],
      proposalIds: ['prop-doc-migration', 'prop-caching-owner'],
    },
    {
      id: 'mtg-observability',
      title: 'Observability Overhaul',
      state: 'archived',
      project: 'Platform',
      date: '5d ago',
      dateLong: 'Apr 17, 2026',
      durationMin: 48,
      participants: ['rk', 'sj'],
      preview: 'Migration from syslog forwarders to Datadog agents; security review checkpoint.',
      taskIds: ['TSK-088'],
      docIds: [],
      proposalIds: [],
    },
    {
      id: 'mtg-pipeline',
      title: 'Pipeline Reliability',
      state: 'archived',
      project: 'Platform',
      date: '1w ago',
      dateLong: 'Apr 15, 2026',
      durationMin: 38,
      participants: ['ml', 'sj'],
      preview: 'Retry/backoff policy, failure-mode taxonomy, worker saturation metrics.',
      taskIds: ['TSK-112'],
      docIds: [],
      proposalIds: [],
    },
    {
      id: 'mtg-latency',
      title: 'Latency Sweep',
      state: 'archived',
      project: 'Project Alpha · Engineering',
      date: '2w ago',
      dateLong: 'Apr 08, 2026',
      durationMin: 52,
      participants: ['dc', 'sj'],
      preview: 'Cold-start profiling on inference workers after autoscale-down.',
      taskIds: ['TSK-096'],
      docIds: [],
      proposalIds: [],
    },
  ];

  // AI proposals — the "new surface". Summaries, agendas, proposed solutions.
  const proposals = [
    {
      id: 'prop-chunking',
      kind: 'solution',
      meetingId: 'mtg-live',
      title: 'Use 512-token windows with 64-token overlap as the RAG default',
      rationale: 'Recall@10 peaks at 512/64 on the meetings corpus. Token budget stays within 18% of the 256-window baseline. Largest win on mid-length meetings (30–60 min).',
      details: 'Benchmarks show a 14% Recall@10 improvement at 512/64 vs the current 1024/128 default, with inference cost increasing only 6% because batching amortizes the overhead. Failure mode is long meetings (>90 min) where context fragmentation costs 3–4%. Recommended guardrail: auto-switch to 1024 windows for meetings over 75 min.\n\nNext step if accepted: land as the default in src/rag/chunk.rs, gate behind EPIDOTE_RAG_CHUNK_STRATEGY=v2 for one week.',
      evidence: [
        { kind: 'transcript', ts: '01:22:04', who: 'sj', text: 'We discussed implementing DataLoader to batch those requests. Did we get a chance to prototype that on the staging environment in AWS-East-1?' },
        { kind: 'vault', docId: 'doc-chunk-bench', note: 'Recall@10 peaks at 512/64 in the benchmark table.' },
      ],
      confidence: 0.82,
      status: 'pending',
      generated: '3 min ago',
      relatedTasks: ['TSK-092'],
      relatedDocs: ['doc-chunk-bench', 'doc-embed-arch'],
    },
    {
      id: 'prop-extract',
      kind: 'task',
      meetingId: 'mtg-live',
      title: 'Create TSK: Benchmark DataLoader batching on GraphQL resolver',
      rationale: 'Sarah mentioned staging on AWS-East-1 @ 01:23:48 and tied it to overnight perf monitoring. Currently no task captures this; tagging David as owner.',
      details: 'Proposed owner: David C. Proposed due: next Monday. Proposed parent meeting: System Architecture Sync. Baseline metric: p95 resolver latency on /meeting/:id/participants — currently 420ms.',
      evidence: [
        { kind: 'transcript', ts: '01:23:48', who: 'sj', text: 'If we push that update by end of day, we can monitor the performance metrics overnight.' },
      ],
      confidence: 0.91,
      status: 'pending',
      generated: '1 min ago',
      relatedTasks: [],
      relatedDocs: [],
    },
    {
      id: 'prop-roadmap',
      kind: 'agenda',
      meetingId: 'mtg-q3roadmap',
      title: 'Proposed agenda for Q4 Kickoff (next Tuesday)',
      rationale: 'Based on Q3 roadmap carryover, 3 unresolved TSK items, and Priya\'s retrieval-quality theme. 6 items, estimated 52 min.',
      details: '01. Retrieval quality review (Q3 metrics) — 10m\n02. TSK-092 chunking default · go/no-go — 8m\n03. TSK-118 roadmap one-pager walk-through — 12m\n04. Pentest Q3 remediation status — 7m\n05. Caching RFC v2 resourcing — 10m\n06. Open floor — 5m',
      evidence: [
        { kind: 'vault', docId: 'doc-q3-roadmap', note: 'Carryover items from Q3.' },
      ],
      confidence: 0.74,
      status: 'pending',
      generated: '2h ago',
      relatedTasks: ['TSK-118', 'TSK-092'],
      relatedDocs: ['doc-q3-roadmap'],
    },
    {
      id: 'prop-summary',
      kind: 'summary',
      meetingId: 'mtg-q3roadmap',
      title: 'Q3 Roadmap Planning — summary & decisions',
      rationale: 'Q3 anchored on retrieval quality. TSK-092 (chunking defaults) is the critical dependency. Roadmap re-sequenced so the RAG pipeline cutover lands before the caching rewrite.',
      details: 'Decisions: (1) RAG pipeline cutover moves to week 2 of Q3. (2) Caching rewrite pushed one sprint. (3) Pentest remediation stays in Q3 scope.\n\nOpen questions: ownership of the staged rollout, and whether the eval suite needs a parallel run before cutover.',
      evidence: [
        { kind: 'vault', docId: 'doc-q3-roadmap', note: 'Decisions match what was captured in the roadmap draft.' },
      ],
      confidence: 0.88,
      status: 'approved',
      generated: '5h ago',
      relatedTasks: ['TSK-118', 'TSK-092'],
      relatedDocs: ['doc-q3-roadmap'],
    },
    {
      id: 'prop-doc-migration',
      kind: 'doc',
      meetingId: 'mtg-q3arch',
      title: 'Generated: Migration Manifesto v1.md',
      rationale: 'Full architectural proposal extracted from the meeting transcript. 4 sections, references 2 existing vault notes.',
      details: 'Sections: Phase 1 (schema mapping · Marcus), Phase 2 (event bus · Sarah), Phase 3 (monolith decomposition · David), Risks. Cross-links to [[Embedding Architecture]] and [[Caching RFC v2]].',
      evidence: [
        { kind: 'vault', docId: 'doc-migration', note: 'Draft auto-saved to the Vault under Architecture/.' },
      ],
      confidence: 0.79,
      status: 'pending',
      generated: '2d ago',
      relatedTasks: ['TSK-104'],
      relatedDocs: ['doc-migration', 'doc-embed-arch'],
    },
    {
      id: 'prop-caching-owner',
      kind: 'task',
      meetingId: 'mtg-q3arch',
      title: 'Create TSK: Nominate owner for Caching RFC v2 resourcing',
      rationale: 'Caching rewrite was re-sequenced but no owner was explicitly assigned in the meeting. Auto-routing to the on-call architect.',
      details: 'Proposed owner: Marcus L. Proposed due: end of Q3 week 3.',
      evidence: [
        { kind: 'vault', docId: 'doc-caching-rfc', note: 'RFC v2 lacks an assigned owner field.' },
      ],
      confidence: 0.68,
      status: 'pending',
      generated: '2d ago',
      relatedTasks: ['TSK-104'],
      relatedDocs: ['doc-caching-rfc'],
    },
  ];

  // Transcript for the live meeting.
  const liveTranscript = [
    { speaker: 'dc', ts: '01:21:15', text: "So the main issue we're seeing with the current architecture is the latency when querying nested relationships. The GraphQL resolver is hitting the database sequentially." },
    { speaker: 'sj', ts: '01:22:04', text: "Right. We discussed implementing DataLoader to batch those requests. Did we get a chance to prototype that on the staging environment in AWS-East-1?", highlight: 'AWS-East-1 · staging' },
    { speaker: 'dc', ts: '01:22:38', text: "Not yet. I was waiting on David's indexing work to land first so we'd be measuring the right baseline." },
    { speaker: 'sj', ts: '01:23:48', text: "If we push that update by end of day, we can monitor the performance metrics overnight. I'll create a Jira ticket for the migration▌", live: true },
  ];

  // Activity feed — used by Today to fill empty space.
  const activity = [
    { when: '2 min ago', kind: 'proposal', text: 'AI extracted 2 proposals from System Architecture Sync (live).', targetKind: 'proposals' },
    { when: '38 min ago', kind: 'task', text: 'TSK-088 blocked — awaiting security approval on Datadog agent.', targetKind: 'tasks', targetId: 'TSK-088' },
    { when: '6h ago', kind: 'meeting', text: 'Q3 Roadmap Planning finished processing. Summary ready to review.', targetKind: 'meetings', targetId: 'mtg-q3roadmap' },
    { when: 'yesterday', kind: 'doc', text: 'Migration Manifesto v1 auto-drafted to Vault/Architecture/.', targetKind: 'vault', targetId: 'doc-migration' },
    { when: '2d ago', kind: 'proposal', text: 'Caching RFC ownership proposal generated (confidence 68%).', targetKind: 'proposals', targetId: 'prop-caching-owner' },
  ];

  // Calendar events (next 14 days).
  const calendarEvents = [
    { date: '2026-04-22', time: '15:00', title: 'System Architecture Sync', kind: 'meeting', meetingId: 'mtg-live' },
    { date: '2026-04-23', time: '10:00', title: 'TSK-088 due', kind: 'deadline', taskId: 'TSK-088' },
    { date: '2026-04-24', time: '14:00', title: 'Q4 Kickoff', kind: 'meeting' },
    { date: '2026-04-24', time: '17:00', title: 'TSK-118 due', kind: 'deadline', taskId: 'TSK-118' },
    { date: '2026-04-26', time: null, title: 'TSK-092 due', kind: 'deadline', taskId: 'TSK-092' },
    { date: '2026-04-28', time: '11:00', title: 'Security Review', kind: 'meeting' },
    { date: '2026-05-01', time: null, title: 'TSK-104 due', kind: 'deadline', taskId: 'TSK-104' },
    { date: '2026-05-06', time: null, title: 'TSK-112 due', kind: 'deadline', taskId: 'TSK-112' },
  ];

  return {
    now,
    people,
    tasks,
    docs,
    meetings,
    proposals,
    liveTranscript,
    calendarEvents,
    activity,
    // lookup helpers
    taskById: (id) => tasks.find((t) => t.id === id),
    docById: (id) => docs.find((d) => d.id === id),
    meetingById: (id) => meetings.find((m) => m.id === id),
    proposalById: (id) => proposals.find((p) => p.id === id),
    personById: (id) => people[id],
  };
})();
