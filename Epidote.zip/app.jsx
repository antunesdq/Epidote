// Epidote — shell, rail, topbar, cmd-k. Pulls in all the pages.

const { useState, useEffect, useRef, useMemo, useCallback } = React;

// ── icons via Material Symbols ──
function Icon({ name, size = 18, style }) {
  return (
    <span className="mi" style={{ fontSize: size, ...style }}>{name}</span>
  );
}
window.Icon = Icon;

// ── nav items ──
const NAV = [
  { id: 'today', label: 'Today', glyph: 'today' },
  { id: 'meetings', label: 'Meetings', glyph: 'graphic_eq' },
  { id: 'tasks', label: 'Tasks', glyph: 'check_circle' },
  { id: 'proposals', label: 'Proposals', glyph: 'auto_awesome' },
  { id: 'vault', label: 'Vault', glyph: 'hub' },
  { id: 'calendar', label: 'Calendar', glyph: 'calendar_month' },
];

function Rail({ current, onNav, onRecord, counts }) {
  return (
    <aside className="rail">
      <div className="rail-brand">
        <div className="mark">E</div>
        <div>
          <div className="wordmark">Epidote</div>
          <div className="kicker">Tech Intelligence</div>
        </div>
      </div>

      {NAV.map((item) => (
        <div
          key={item.id}
          className={`nav-item ${current === item.id ? 'active' : ''}`}
          onClick={() => onNav(item.id)}
        >
          <Icon name={item.glyph} size={17} />
          <span>{item.label}</span>
          {counts[item.id] != null && <span className="count">{counts[item.id]}</span>}
        </div>
      ))}

      <div className="rail-bottom">
        <div
          className={`nav-item ${current === 'settings' ? 'active' : ''}`}
          onClick={() => onNav('settings')}
        >
          <Icon name="settings" size={17} />
          <span>Settings</span>
        </div>
        <button className="record-cta" onClick={onRecord}>
          <span className="dot" />
          <span>Record meeting</span>
        </button>
      </div>
    </aside>
  );
}

function TopBar({ crumb, onOpenCmdK }) {
  return (
    <div className="topbar">
      <div className="crumb">{crumb}</div>
      <button className="cmdk-trigger" onClick={onOpenCmdK}>
        <Icon name="search" size={14} />
        <span>Search meetings, tasks, notes…</span>
        <span className="kbd">⌘K</span>
      </button>
      <div className="icon-btn"><Icon name="notifications" size={16} /></div>
      <div className="icon-btn"><Icon name="help" size={16} /></div>
      <div className="avatar">MA</div>
    </div>
  );
}

// ── Cmd-K ──
function CmdK({ open, onClose, onOpen }) {
  const [q, setQ] = useState('');
  const inputRef = useRef(null);
  useEffect(() => { if (open) { setQ(''); setTimeout(() => inputRef.current?.focus(), 50); } }, [open]);

  if (!open) return null;
  const d = window.EpidoteData;
  const query = q.toLowerCase().trim();
  const results = query
    ? [
        ...d.meetings.filter((m) => m.title.toLowerCase().includes(query)).slice(0, 3).map((m) => ({ kind: 'Meeting', glyph: 'graphic_eq', title: m.title, sub: m.dateLong, action: () => onOpen('meetings', { meetingId: m.id }) })),
        ...d.tasks.filter((t) => t.title.toLowerCase().includes(query) || t.id.toLowerCase().includes(query)).slice(0, 3).map((t) => ({ kind: 'Task', glyph: 'check_circle', title: t.title, sub: t.id, action: () => onOpen('tasks', { taskId: t.id }) })),
        ...d.docs.filter((doc) => doc.name.toLowerCase().includes(query)).slice(0, 3).map((doc) => ({ kind: 'Note', glyph: 'description', title: doc.name, sub: doc.folder, action: () => onOpen('vault', { docId: doc.id }) })),
      ]
    : [
        { kind: 'Jump', glyph: 'today', title: 'Go to Today', sub: '', action: () => onOpen('today') },
        { kind: 'Jump', glyph: 'graphic_eq', title: 'Go to Meetings', sub: '', action: () => onOpen('meetings') },
        { kind: 'Action', glyph: 'fiber_manual_record', title: 'Start new recording', sub: '', action: () => onOpen('meetings', { startRecording: true }) },
        { kind: 'Action', glyph: 'auto_awesome', title: 'Review AI Proposals', sub: `${d.proposals.filter((p) => p.status === 'pending').length} pending`, action: () => onOpen('proposals') },
      ];

  return (
    <div className="cmdk-backdrop" onClick={onClose}>
      <div className="cmdk" onClick={(e) => e.stopPropagation()}>
        <div className="cmdk-input-row">
          <Icon name="search" size={16} style={{ color: 'var(--text-muted)' }} />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search or type a command…"
            onKeyDown={(e) => { if (e.key === 'Escape') onClose(); if (e.key === 'Enter' && results[0]) { results[0].action(); onClose(); } }}
          />
          <span className="kbd">ESC</span>
        </div>
        <div className="cmdk-results">
          {results.length === 0 && <div className="cmdk-empty">No matches.</div>}
          {results.map((r, i) => (
            <div key={i} className="cmdk-row" onClick={() => { r.action(); onClose(); }}>
              <Icon name={r.glyph} size={15} style={{ color: 'var(--text-dim)' }} />
              <div className="cmdk-text">
                <div className="cmdk-title">{r.title}</div>
                {r.sub && <div className="cmdk-sub">{r.sub}</div>}
              </div>
              <span className="cmdk-kind">{r.kind}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── main App shell ──
function App() {
  const [variant, setVariant] = useState(() => localStorage.getItem('epidote.variant') || 'terminal');
  const [current, setCurrent] = useState(() => localStorage.getItem('epidote.page') || 'today');
  const [cmdkOpen, setCmdkOpen] = useState(false);
  const [routeState, setRouteState] = useState({}); // { meetingId, taskId, docId }
  const [tweaksVisible, setTweaksVisible] = useState(false);

  useEffect(() => { localStorage.setItem('epidote.variant', variant); }, [variant]);
  useEffect(() => { localStorage.setItem('epidote.page', current); }, [current]);

  // Tweaks host protocol.
  useEffect(() => {
    const handler = (e) => {
      if (!e.data || typeof e.data !== 'object') return;
      if (e.data.type === '__activate_edit_mode') setTweaksVisible(true);
      if (e.data.type === '__deactivate_edit_mode') setTweaksVisible(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  // Keyboard: Cmd-K.
  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setCmdkOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const navigate = useCallback((page, state = {}) => {
    setCurrent(page);
    setRouteState(state);
  }, []);

  const d = window.EpidoteData;
  const counts = useMemo(() => ({
    meetings: d.meetings.filter((m) => m.state === 'live').length || null,
    tasks: d.tasks.filter((t) => t.status !== 'done' && t.dueSoon).length || null,
    proposals: d.proposals.filter((p) => p.status === 'pending').length || null,
  }), []);

  const crumb = {
    today: <>EPIDOTE / <strong>Today</strong></>,
    meetings: <>EPIDOTE / <strong>Meetings</strong></>,
    tasks: <>EPIDOTE / <strong>Tasks</strong></>,
    proposals: <>EPIDOTE / <strong>Proposals</strong> <span style={{color:'var(--text-muted)', marginLeft:6}}>· AI inbox</span></>,
    vault: <>EPIDOTE / <strong>Vault</strong></>,
    calendar: <>EPIDOTE / <strong>Calendar</strong></>,
    settings: <>EPIDOTE / <strong>Settings</strong></>,
  }[current];

  const page = {
    today: <TodayPage navigate={navigate} />,
    meetings: <MeetingsPage navigate={navigate} routeState={routeState} />,
    tasks: <TasksPage navigate={navigate} routeState={routeState} />,
    proposals: <ProposalsPage navigate={navigate} />,
    vault: <VaultPage navigate={navigate} routeState={routeState} />,
    calendar: <CalendarPage navigate={navigate} />,
    settings: <SettingsPage />,
  }[current] || <TodayPage navigate={navigate} />;

  return (
    <div className="app-window" data-variant={variant} id="root-inner">
      <div className="title-bar">
        <div className="traffic"><div/><div/><div/></div>
        <div className="title">epidote — dev build</div>
        <div style={{ width: 50 }} />
      </div>
      <div className="app-body">
        <Rail
          current={current}
          onNav={(p) => navigate(p)}
          onRecord={() => navigate('meetings', { startRecording: true })}
          counts={counts}
        />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
          <TopBar crumb={crumb} onOpenCmdK={() => setCmdkOpen(true)} />
          <div className="main" key={current}>{page}</div>
        </div>
      </div>

      <CmdK open={cmdkOpen} onClose={() => setCmdkOpen(false)} onOpen={navigate} />

      {tweaksVisible && (
        <div className="tweaks">
          <div className="tweaks-title">Tweaks</div>
          <div className="tweaks-row">
            <label>Visual variant</label>
            <div className="tweak-variants">
              {['terminal', 'paper', 'graphite'].map((v) => (
                <button
                  key={v}
                  className={variant === v ? 'active' : ''}
                  onClick={() => setVariant(v)}
                >{v}</button>
              ))}
            </div>
          </div>
          <div className="tweaks-row">
            <label>Jump to</label>
            <div className="tweak-variants" style={{ gridTemplateColumns: '1fr 1fr' }}>
              {[['today','Today'],['meetings','Meeting (live)']].map(([id,l]) => (
                <button key={id} onClick={() => navigate(id === 'meetings' ? 'meetings' : id, id === 'meetings' ? { meetingId: 'mtg-live' } : {})}>{l}</button>
              ))}
              {[['proposals','Proposals'],['tasks','Tasks']].map(([id,l]) => (
                <button key={id} onClick={() => navigate(id)}>{l}</button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

window.App = App;

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
