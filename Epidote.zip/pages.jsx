// Epidote pages — Today, Meetings, Tasks, Proposals, Vault, Calendar, Settings.

const { useState: _useState, useEffect: _useEffect, useMemo: _useMemo, useRef: _useRef } = React;

// ── shared bits ──
function Avatar({ personId, size = 26 }) {
  const p = window.EpidoteData.personById(personId);
  if (!p) return null;
  return (
    <div className="t-av" style={{ width: size, height: size, fontSize: size * 0.38, color: p.accent, borderColor: p.accent }}>
      {p.initials}
    </div>
  );
}

function AvStack({ ids, max = 4 }) {
  const shown = ids.slice(0, max);
  const extra = ids.length - shown.length;
  return (
    <div className="avstack">
      {shown.map((id) => <Avatar key={id} personId={id} size={26} />)}
      {extra > 0 && <div className="t-av" style={{ width: 26, height: 26, fontSize: 10, color: 'var(--text-dim)' }}>+{extra}</div>}
    </div>
  );
}

function StatusDot({ status }) {
  const color = { active: 'var(--primary)', blocked: 'var(--error)', triage: 'var(--outline)', done: 'var(--text-muted)' }[status] || 'var(--outline)';
  return <span className="status-dot" style={{ background: color }} />;
}

// ═══ Today ═══
function TodayPage({ navigate }) {
  const d = window.EpidoteData;
  const liveMtg = d.meetings.find((m) => m.state === 'live');
  const pendingProps = d.proposals.filter((p) => p.status === 'pending');
  const dueTasks = d.tasks.filter((t) => t.dueSoon && t.status !== 'done');
  const activeTasks = d.tasks.filter((t) => t.status === 'active');
  const todayEvts = d.calendarEvents.filter((e) => e.date === '2026-04-22');

  return (
    <div className="page">
      <div className="today-grid">
        <div>
          <div className="today-hero">
            <div className="day-strip">
              <span><strong>Wednesday</strong>, Apr 22</span>
              <span>·</span>
              <span>3 meetings today</span>
              <span>·</span>
              <span>{pendingProps.length} proposals awaiting review</span>
            </div>

            {liveMtg && (
              <div className="agenda-item" onClick={() => navigate('meetings', { meetingId: liveMtg.id })}>
                <span className="agenda-time">{liveMtg.elapsed?.slice(0,5) || 'LIVE'}</span>
                <span className="pill live"><span className="dot" />Live</span>
                <div className="agenda-main">
                  <div className="title">{liveMtg.title}</div>
                  <div className="sub">{liveMtg.project} · {liveMtg.participants.length} participants</div>
                </div>
                <AvStack ids={liveMtg.participants} />
              </div>
            )}
            {todayEvts.filter((e) => e.kind === 'meeting' && e.meetingId !== liveMtg?.id).map((e, i) => (
              <div key={i} className="agenda-item">
                <span className="agenda-time">{e.time}</span>
                <span className="agenda-kind-dot" style={{ background: 'var(--primary)' }} />
                <div className="agenda-main">
                  <div className="title">{e.title}</div>
                  <div className="sub">Scheduled</div>
                </div>
              </div>
            ))}
            {todayEvts.filter((e) => e.kind === 'deadline').map((e, i) => (
              <div key={i} className="agenda-item" onClick={() => navigate('tasks', { taskId: e.taskId })}>
                <span className="agenda-time">{e.time || '—'}</span>
                <span className="agenda-kind-dot" style={{ background: 'var(--error)' }} />
                <div className="agenda-main">
                  <div className="title">{e.title}</div>
                  <div className="sub">Task deadline</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{ height: 20 }} />

          <div className="card">
            <div className="card-title">
              <span className="eyebrow">Proposals awaiting you</span>
              <span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{pendingProps.length} PENDING</span>
            </div>
            {pendingProps.slice(0, 3).map((p) => (
              <ProposalCard key={p.id} prop={p} onOpen={() => navigate('proposals', { proposalId: p.id })} compact />
            ))}
          </div>
        </div>

        <div>
          <div className="card" style={{ marginBottom: 20 }}>
            <div className="card-title"><span className="eyebrow">Your tasks</span><span style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', cursor: 'pointer' }} onClick={() => navigate('tasks')}>VIEW BOARD →</span></div>
            <div className="stat-row">
              <div className="stat">
                <div className="num accent">{activeTasks.length}</div>
                <div className="lbl">Active</div>
              </div>
              <div className="stat">
                <div className="num">{dueTasks.length}</div>
                <div className="lbl">Due soon</div>
              </div>
              <div className="stat">
                <div className="num">{d.tasks.filter((t) => t.status === 'blocked').length}</div>
                <div className="lbl">Blocked</div>
              </div>
            </div>
          </div>

          <div className="card" style={{ marginBottom: 20 }}>
            <div className="card-title"><span className="eyebrow">Due soon</span></div>
            {dueTasks.map((t) => (
              <div key={t.id} className="mini-row" onClick={() => navigate('tasks', { taskId: t.id })}>
                <StatusDot status={t.status} />
                <span className="id">{t.id}</span>
                <span style={{ flex: 1, minWidth: 0, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t.title}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: t.dueSoon ? 'var(--primary)' : 'var(--text-muted)' }}>{t.due}</span>
              </div>
            ))}
          </div>

          <div className="card">
            <div className="card-title"><span className="eyebrow">Activity</span></div>
            {d.activity.map((a, i) => (
              <div key={i} className="activity-row" onClick={() => a.targetId ? navigate(a.targetKind, a.targetKind === 'tasks' ? { taskId: a.targetId } : a.targetKind === 'meetings' ? { meetingId: a.targetId } : a.targetKind === 'vault' ? { docId: a.targetId } : a.targetKind === 'proposals' ? { proposalId: a.targetId } : {}) : navigate(a.targetKind)}>
                <span className={`activity-dot ${a.kind}`} />
                <div className="activity-body">
                  <div className="activity-text">{a.text}</div>
                  <div className="activity-when">{a.when}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══ Meetings ═══
function MeetingsPage({ navigate, routeState }) {
  const d = window.EpidoteData;
  const [selectedId, setSelectedId] = _useState(routeState.meetingId || d.meetings[0].id);
  const [filter, setFilter] = _useState('all');
  const [tab, setTab] = _useState('transcript');

  _useEffect(() => {
    if (routeState.meetingId) setSelectedId(routeState.meetingId);
    if (routeState.startRecording) setSelectedId('mtg-live');
  }, [routeState.meetingId, routeState.startRecording]);

  const filtered = d.meetings.filter((m) => filter === 'all' || m.state === filter);
  const mtg = d.meetingById(selectedId);

  return (
    <div className="meetings-wrap">
      <div className="mlist">
        <div className="mlist-search">
          <Icon name="search" size={14} />
          <input placeholder="Search archive…" />
        </div>
        <div className="mlist-filters">
          {[['all','All'],['live','Live'],['processing','Processing'],['archived','Archive']].map(([k,l]) => (
            <button key={k} className={`filter-chip ${filter === k ? 'active' : ''}`} onClick={() => setFilter(k)}>{l}</button>
          ))}
        </div>
        {filtered.map((m) => (
          <div key={m.id} className={`mcard ${selectedId === m.id ? 'active' : ''}`} onClick={() => { setSelectedId(m.id); setTab(m.state === 'live' ? 'transcript' : 'brief'); }}>
            <div className="mcard-top">
              <span className="mcard-date">{m.date}</span>
              {m.state === 'live' && <span className="pill live"><span className="dot" />Live</span>}
              {m.state === 'processing' && <span className="pill processing">Processing</span>}
            </div>
            <h3>{m.title}</h3>
            <p>{m.preview}</p>
            <div className="mcard-meta">
              <span>{m.durationMin}m</span>
              <span>·</span>
              <span>{m.participants.length} people</span>
              {m.taskIds.length > 0 && (<><span>·</span><span>{m.taskIds.length} tasks</span></>)}
            </div>
          </div>
        ))}
      </div>

      {mtg && <MeetingDetail mtg={mtg} tab={tab} setTab={setTab} navigate={navigate} />}
    </div>
  );
}

function MeetingDetail({ mtg, tab, setTab, navigate }) {
  const d = window.EpidoteData;
  const taskCount = mtg.taskIds.length;
  const docCount = mtg.docIds.length;
  const propCount = mtg.proposalIds.length;

  return (
    <div className="mdetail">
      <div className="mdetail-head">
        <div className="mdetail-title-row">
          <h1>{mtg.title}</h1>
          {mtg.state === 'live' && <span className="pill live"><span className="dot" />Live</span>}
          {mtg.state === 'processing' && <span className="pill processing">Processing · {mtg.processingStep}</span>}
          {mtg.state === 'archived' && <span className="pill archived">Archived</span>}
        </div>
        <div className="mdetail-meta">
          <span><Icon name="folder" size={13} />{mtg.project}</span>
          <span><Icon name="schedule" size={13} />{mtg.durationMin} min</span>
          <span><Icon name="group" size={13} />{mtg.participants.length} participants</span>
          <AvStack ids={mtg.participants} />
        </div>
      </div>
      <div className="tab-bar">
        <button className={`tab ${tab==='transcript'?'active':''}`} onClick={() => setTab('transcript')}><Icon name="graphic_eq" size={14}/>Transcript</button>
        <button className={`tab ${tab==='brief'?'active':''}`} onClick={() => setTab('brief')}><Icon name="auto_awesome" size={14}/>Brief</button>
        <button className={`tab ${tab==='proposals'?'active':''}`} onClick={() => setTab('proposals')}><Icon name="bolt" size={14}/>Proposals{propCount > 0 && <span className="count">{propCount}</span>}</button>
        <button className={`tab ${tab==='tasks'?'active':''}`} onClick={() => setTab('tasks')}><Icon name="check_circle" size={14}/>Tasks{taskCount > 0 && <span className="count">{taskCount}</span>}</button>
        <button className={`tab ${tab==='docs'?'active':''}`} onClick={() => setTab('docs')}><Icon name="description" size={14}/>Docs{docCount > 0 && <span className="count">{docCount}</span>}</button>
      </div>
      <div className="mdetail-body">
        {tab === 'transcript' && <TranscriptTab mtg={mtg} />}
        {tab === 'brief' && <BriefTab mtg={mtg} navigate={navigate} />}
        {tab === 'proposals' && <MtgProposalsTab mtg={mtg} navigate={navigate} />}
        {tab === 'tasks' && <MtgTasksTab mtg={mtg} navigate={navigate} />}
        {tab === 'docs' && <MtgDocsTab mtg={mtg} navigate={navigate} />}
      </div>
    </div>
  );
}

function TranscriptTab({ mtg }) {
  const d = window.EpidoteData;
  const [elapsed, setElapsed] = _useState(mtg.elapsed || '01:24:03');

  _useEffect(() => {
    if (mtg.state !== 'live') return;
    const t = setInterval(() => {
      setElapsed((prev) => {
        const [h, m, s] = prev.split(':').map(Number);
        const total = h*3600 + m*60 + s + 1;
        const nh = String(Math.floor(total/3600)).padStart(2,'0');
        const nm = String(Math.floor((total%3600)/60)).padStart(2,'0');
        const ns = String(total%60).padStart(2,'0');
        return `${nh}:${nm}:${ns}`;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [mtg.state]);

  return (
    <>
      {mtg.state === 'live' && (
        <>
          <div className="live-strip">
            <div>
              <div className="elapsed">{elapsed}</div>
              <div className="elapsed-lbl">Elapsed</div>
            </div>
            <div style={{ color: 'var(--text-dim)', fontSize: 12, fontFamily: 'var(--font-mono)' }}>
              Sarah J. speaking · AWS-East-1
            </div>
            <div className="transport">
              <button className="tbtn"><Icon name="mic_off" size={16}/></button>
              <button className="tbtn"><Icon name="pause" size={16}/></button>
              <button className="tbtn danger"><Icon name="stop" size={16}/></button>
            </div>
          </div>
          <div className="waveform">
            {Array.from({ length: 140 }).map((_, i) => {
              const h = 20 + Math.abs(Math.sin(i * 0.4) + Math.sin(i * 0.13)) * 45;
              return <div key={i} className="wbar" style={{ height: h, opacity: i > 110 ? 0.3 : 0.75 }} />;
            })}
          </div>
        </>
      )}
      {mtg.state === 'processing' && (
        <div className="live-strip" style={{ marginBottom: 18 }}>
          <div>
            <div className="elapsed" style={{ color: 'var(--accent-amber)', fontSize: 16 }}>{mtg.processingStep}…</div>
            <div className="elapsed-lbl">AI post-processing</div>
          </div>
          <div style={{ flex: 1, marginLeft: 16, height: 4, background: 'var(--surface-highest)', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{ width: `${mtg.processingPct}%`, height: '100%', background: 'var(--accent-amber)' }} />
          </div>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-dim)' }}>{mtg.processingPct}%</span>
        </div>
      )}
      <div>
        {(mtg.state === 'live' ? d.liveTranscript : sampleArchivedTranscript(mtg)).map((e, i) => {
          const p = d.personById(e.speaker);
          return (
            <div key={i} className="t-entry">
              <div className="t-av" style={{ color: p.accent, borderColor: p.accent }}>{p.initials}</div>
              <div className="t-main">
                <div className="t-hdr">
                  <span className="t-name" style={{ color: p.accent }}>{p.name}</span>
                  <span className="t-ts">{e.ts}</span>
                  {e.live && <span className="pill live"><span className="dot"/>Live</span>}
                </div>
                <div className="t-body">{e.text}</div>
                {e.highlight && <div className="t-hl">◆ AI tag · {e.highlight}</div>}
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

function sampleArchivedTranscript(mtg) {
  return [
    { speaker: 'sj', ts: '02:30', text: 'Let me start by framing the problem as we saw it last sprint.' },
    { speaker: 'dc', ts: '03:45', text: `The ${mtg.title.toLowerCase()} came down to three decisions. First was scope.` },
    { speaker: 'sj', ts: '05:12', text: 'Agreed. And I think the path forward lands cleanly with what Priya suggested.', highlight: 'Decision logged' },
  ];
}

function BriefTab({ mtg, navigate }) {
  const d = window.EpidoteData;
  const proposals = mtg.proposalIds.map(d.proposalById).filter(Boolean);
  const summary = proposals.find((p) => p.kind === 'summary');
  const agenda = proposals.find((p) => p.kind === 'agenda');

  if (mtg.state === 'live') {
    return (
      <div style={{ padding: 32, textAlign: 'center', color: 'var(--text-dim)', background: 'var(--surface-low)', border: '1px dashed var(--outline-variant)', borderRadius: 6 }}>
        <Icon name="hourglass_empty" size={24} style={{ color: 'var(--text-muted)' }} />
        <p style={{ marginTop: 12, fontSize: 13 }}>The AI brief is generated after the meeting ends.</p>
        <p style={{ marginTop: 4, fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>
          {proposals.length} live proposals already captured — see the Proposals tab.
        </p>
      </div>
    );
  }

  return (
    <>
      {summary && (
        <div className="brief-section">
          <div className="eyebrow">Summary</div>
          <div className="brief-body">{summary.rationale}</div>
        </div>
      )}

      {agenda && (
        <div className="brief-section">
          <h3><Icon name="event_note" size={16}/>Proposed follow-up agenda</h3>
          <div className="brief-body" style={{ padding: 0 }}>
            <ol className="agenda-list" start="1">
              <li><span className="num">01</span><span>Retrieval quality review (Q3 metrics)</span><span className="dur">10 min</span></li>
              <li><span className="num">02</span><span>TSK-092 chunking default · go/no-go</span><span className="dur">8 min</span></li>
              <li><span className="num">03</span><span>TSK-118 roadmap one-pager walk-through</span><span className="dur">12 min</span></li>
              <li><span className="num">04</span><span>Pentest Q3 remediation status</span><span className="dur">7 min</span></li>
              <li><span className="num">05</span><span>Caching RFC v2 resourcing</span><span className="dur">10 min</span></li>
              <li><span className="num">06</span><span>Open floor</span><span className="dur">5 min</span></li>
            </ol>
          </div>
        </div>
      )}

      {proposals.length > 0 && (
        <div className="brief-section" style={{ background: 'var(--surface-low)', border: '1px solid var(--outline-variant)', borderRadius: 6, padding: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Icon name="bolt" size={16} style={{ color: 'var(--accent-amber)' }} />
            <span style={{ fontSize: 13 }}>{proposals.length} AI proposal{proposals.length > 1 ? 's' : ''} from this meeting</span>
            <button className="btn" style={{ marginLeft: 'auto' }} onClick={() => navigate('proposals', { meetingFilter: mtg.id })}>Review proposals →</button>
          </div>
        </div>
      )}

      {proposals.length === 0 && !summary && !agenda && (
        <div style={{ color: 'var(--text-dim)', fontSize: 13, padding: 20 }}>No AI brief generated for this meeting.</div>
      )}
    </>
  );
}

function MtgProposalsTab({ mtg, navigate }) {
  const d = window.EpidoteData;
  const proposals = mtg.proposalIds.map(d.proposalById).filter(Boolean);
  return (
    <>
      <p className="eyebrow" style={{ marginBottom: 14 }}>AI proposals extracted from this meeting · {proposals.length}</p>
      {proposals.length === 0 && <div style={{ color: 'var(--text-dim)', fontSize: 13 }}>No proposals generated yet.</div>}
      {proposals.map((p) => <ProposalCard key={p.id} prop={p} onOpen={() => navigate('proposals', { proposalId: p.id })} />)}
    </>
  );
}

function MtgTasksTab({ mtg, navigate }) {
  const d = window.EpidoteData;
  const tasks = mtg.taskIds.map(d.taskById).filter(Boolean);
  return (
    <>
      <p className="eyebrow" style={{ marginBottom: 14 }}>Action items extracted from this meeting · {tasks.length}</p>
      {tasks.map((t) => (
        <div key={t.id} className="drawer-row" onClick={() => navigate('tasks', { taskId: t.id })}>
          <StatusDot status={t.status} />
          <span className="id" style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--primary)' }}>{t.id}</span>
          <span style={{ flex: 1 }}>{t.title}</span>
          <Avatar personId={t.owner} size={22} />
          <span className="ext" style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5 }}>{t.due || '—'}</span>
          <Icon name="open_in_new" size={14} style={{ color: 'var(--text-muted)' }} />
        </div>
      ))}
      {tasks.length === 0 && <div style={{ color: 'var(--text-dim)', fontSize: 13 }}>No tasks extracted yet.</div>}
    </>
  );
}

function MtgDocsTab({ mtg, navigate }) {
  const d = window.EpidoteData;
  const docs = mtg.docIds.map(d.docById).filter(Boolean);
  return (
    <>
      <p className="eyebrow" style={{ marginBottom: 14 }}>Documents generated from this meeting</p>
      {docs.map((doc) => (
        <div key={doc.id} className="drawer-row" onClick={() => navigate('vault', { docId: doc.id })}>
          <Icon name="description" size={16} style={{ color: 'var(--text-dim)' }} />
          <span style={{ flex: 1 }}>{doc.name}</span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--text-muted)' }}>{doc.folder} · {doc.updated}</span>
          <Icon name="open_in_new" size={14} style={{ color: 'var(--text-muted)' }} />
        </div>
      ))}
      {docs.length === 0 && <div style={{ color: 'var(--text-dim)', fontSize: 13 }}>No docs generated.</div>}
    </>
  );
}

// ═══ Tasks ═══
function TasksPage({ navigate, routeState }) {
  const d = window.EpidoteData;
  const [selectedId, setSelectedId] = _useState(routeState.taskId || null);

  _useEffect(() => { if (routeState.taskId) setSelectedId(routeState.taskId); }, [routeState.taskId]);

  const cols = [
    { key: 'triage', label: 'Triage', dot: 'var(--outline)' },
    { key: 'active', label: 'Active', dot: 'var(--primary)' },
    { key: 'blocked', label: 'Blocked', dot: 'var(--error)' },
  ];

  return (
    <>
      <div className="page" style={{ paddingBottom: 8 }}>
        <h1 className="page-h1">Tasks</h1>
        <p className="page-sub">Technical action items extracted from meetings. Single source of truth — meetings and calendar link in.</p>
      </div>
      <div className="page" style={{ paddingTop: 12, height: 'calc(100% - 80px)' }}>
        <div className="board">
          {cols.map((c) => {
            const tasks = d.tasks.filter((t) => t.status === c.key);
            return (
              <div key={c.key} className="col">
                <div className="col-head">
                  <span className="dot" style={{ background: c.dot }} />
                  <h3>{c.label}</h3>
                  <span className="count">{tasks.length}</span>
                </div>
                <div className="col-body">
                  {tasks.map((t) => (
                    <div key={t.id} className={`tcard ${selectedId === t.id ? 'active' : ''} ${t.status === 'blocked' ? 'blocked' : ''}`} onClick={() => setSelectedId(t.id)}>
                      <div className="id">{t.id}</div>
                      <h4>{t.title}</h4>
                      <div className="tcard-foot">
                        <Avatar personId={t.owner} size={20} />
                        {t.due && <span className={`due ${t.dueSoon ? 'soon' : ''}`}>{t.due}</span>}
                      </div>
                      {(t.meetingId || t.docs.length > 0 || t.proposalId) && (
                        <div className="tcard-links">
                          {t.meetingId && (
                            <div className="tcard-link">
                              <Icon name="graphic_eq" size={12} />
                              <span>{d.meetingById(t.meetingId)?.title}</span>
                            </div>
                          )}
                          {t.proposalId && (
                            <div className="tcard-link" style={{ color: 'var(--accent-amber)' }}>
                              <Icon name="bolt" size={12} />
                              <span>from AI proposal</span>
                            </div>
                          )}
                          {t.docs.slice(0, 2).map((did) => (
                            <div key={did} className="tcard-link">
                              <Icon name="description" size={12} />
                              <span>{d.docById(did)?.name}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {selectedId && <TaskDrawer taskId={selectedId} onClose={() => setSelectedId(null)} navigate={navigate} />}
    </>
  );
}

function TaskDrawer({ taskId, onClose, navigate }) {
  const d = window.EpidoteData;
  const t = d.taskById(taskId);
  if (!t) return null;
  const owner = d.personById(t.owner);
  const mtg = t.meetingId ? d.meetingById(t.meetingId) : null;

  return (
    <>
      <div className="drawer-backdrop" onClick={onClose} />
      <div className="drawer">
        <div className="drawer-head">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 6 }}>
            <span className="drawer-id">{t.id}</span>
            <button className="btn ghost" onClick={onClose}><Icon name="close" size={14}/></button>
          </div>
          <h2>{t.title}</h2>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 12 }}>
            <span className="pill" style={{ color: t.status === 'blocked' ? 'var(--error)' : 'var(--primary)', background: `color-mix(in oklab, ${t.status === 'blocked' ? 'var(--error)' : 'var(--primary)'} 14%, transparent)` }}>
              <StatusDot status={t.status} /> {t.status === 'active' ? 'Active Analysis' : t.status === 'blocked' ? 'Blocked' : 'Triage'}
            </span>
            {t.due && <span style={{ fontFamily: 'var(--font-mono)', fontSize: 11, color: t.dueSoon ? 'var(--primary)' : 'var(--text-dim)' }}>Due {t.due}</span>}
          </div>
        </div>
        <div className="drawer-body">
          {t.blockedNote && <div className="drawer-section"><div className="eyebrow">Blocked</div><div className="blocked-note">{t.blockedNote}</div></div>}

          <div className="drawer-section">
            <div className="eyebrow">Owner</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 13 }}>
              <Avatar personId={t.owner} size={28} />{owner.name}
            </div>
          </div>

          {t.description && (
            <div className="drawer-section">
              <div className="eyebrow">Details</div>
              <p style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.6, margin: 0 }}>{t.description}</p>
            </div>
          )}

          {mtg && (
            <div className="drawer-section">
              <div className="eyebrow">Source meeting</div>
              <div className="drawer-row" onClick={() => navigate('meetings', { meetingId: mtg.id })}>
                <Icon name="graphic_eq" size={16} style={{ color: 'var(--text-dim)' }} />
                <span style={{ flex: 1 }}>{mtg.title}</span>
                <span className="ext" style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5 }}>{mtg.date}</span>
                <Icon name="open_in_new" size={14} style={{ color: 'var(--text-muted)' }} />
              </div>
            </div>
          )}

          {t.proposalId && (() => {
            const prop = d.proposalById(t.proposalId);
            if (!prop) return null;
            return (
              <div className="drawer-section">
                <div className="eyebrow">Originating proposal</div>
                <div className="drawer-row" style={{ borderColor: 'color-mix(in oklab, var(--accent-amber) 30%, transparent)' }} onClick={() => navigate('proposals', { proposalId: prop.id })}>
                  <Icon name="bolt" size={16} style={{ color: 'var(--accent-amber)' }} />
                  <span style={{ flex: 1 }}>{prop.title}</span>
                  <span className="ext" style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5 }}>{Math.round(prop.confidence * 100)}%</span>
                  <Icon name="open_in_new" size={14} style={{ color: 'var(--text-muted)' }} />
                </div>
              </div>
            );
          })()}

          {t.docs.length > 0 && (
            <div className="drawer-section">
              <div className="eyebrow">Vault references</div>
              {t.docs.map((did) => {
                const doc = d.docById(did);
                if (!doc) return null;
                return (
                  <div key={did} className="drawer-row" onClick={() => navigate('vault', { docId: did })}>
                    <Icon name="description" size={16} style={{ color: 'var(--text-dim)' }} />
                    <span style={{ flex: 1 }}>{doc.name}</span>
                    <span className="ext" style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5 }}>{doc.folder}</span>
                    <Icon name="open_in_new" size={14} style={{ color: 'var(--text-muted)' }} />
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

// ═══ Proposals ═══
function ProposalCard({ prop, onOpen, compact }) {
  const d = window.EpidoteData;
  const mtg = prop.meetingId ? d.meetingById(prop.meetingId) : null;
  const kindLabel = { solution: 'Solution', task: 'Task', agenda: 'Agenda', summary: 'Summary', doc: 'Document' }[prop.kind] || prop.kind;
  return (
    <div className="proposal-card" onClick={onOpen} style={{ cursor: 'pointer' }}>
      <div className="head">
        <span className="kind">{kindLabel}</span>
        {mtg && <span style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>from {mtg.title}</span>}
        <span className="conf">{Math.round(prop.confidence * 100)}% confidence</span>
      </div>
      <h4>{prop.title}</h4>
      <p className="rat">{prop.rationale}</p>
      {!compact && (
        <div className="actions" onClick={(e) => e.stopPropagation()}>
          <button className="btn primary"><Icon name="check" size={13}/>Accept</button>
          <button className="btn"><Icon name="edit" size={13}/>Refine</button>
          <button className="btn ghost"><Icon name="close" size={13}/>Dismiss</button>
          <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--text-muted)' }}>{prop.generated}</span>
        </div>
      )}
    </div>
  );
}
window.ProposalCard = ProposalCard;

function ProposalsPage({ navigate, routeState }) {
  const d = window.EpidoteData;
  const [filter, setFilter] = _useState('pending');
  const [selectedId, setSelectedId] = _useState(routeState.proposalId || null);

  _useEffect(() => { if (routeState.proposalId) setSelectedId(routeState.proposalId); }, [routeState.proposalId]);

  const filtered = d.proposals.filter((p) => {
    if (routeState.meetingFilter && p.meetingId !== routeState.meetingFilter) return false;
    return filter === 'all' || p.status === filter;
  });

  const selected = selectedId ? d.proposalById(selectedId) : null;

  if (selected) {
    return <ProposalFocus prop={selected} onClose={() => setSelectedId(null)} navigate={navigate} />;
  }

  return (
    <div className="page">
      <h1 className="page-h1">Proposals</h1>
      <p className="page-sub">AI-generated summaries, agendas, tasks, and solutions. Review and accept to turn them into real work.</p>

      <div className="prop-filter-bar" style={{ marginTop: 20 }}>
        {[['pending','Pending'],['approved','Approved'],['all','All']].map(([k,l]) => (
          <button key={k} className={`filter-chip ${filter === k ? 'active' : ''}`} onClick={() => setFilter(k)}>{l}</button>
        ))}
        <span style={{ marginLeft: 'auto', color: 'var(--text-muted)', fontSize: 11, fontFamily: 'var(--font-mono)' }}>{filtered.length} results</span>
      </div>

      <div className="prop-list">
        {filtered.map((p) => <ProposalCard key={p.id} prop={p} onOpen={() => setSelectedId(p.id)} />)}
      </div>
    </div>
  );
}

function ProposalFocus({ prop, onClose, navigate }) {
  const d = window.EpidoteData;
  const mtg = prop.meetingId ? d.meetingById(prop.meetingId) : null;
  const kindLabel = { solution: 'Solution', task: 'Task', agenda: 'Agenda', summary: 'Summary', doc: 'Document' }[prop.kind] || prop.kind;
  const relTasks = (prop.relatedTasks || []).map(d.taskById).filter(Boolean);
  const relDocs = (prop.relatedDocs || []).map(d.docById).filter(Boolean);

  return (
    <div className="page pfocus">
      <button className="btn ghost pfocus-back" onClick={onClose}>
        <Icon name="arrow_back" size={14} /> Back to Proposals
      </button>

      <div className="pfocus-head">
        <div className="pfocus-meta-row">
          <span className="pfocus-kind">{kindLabel}</span>
          <span className="pfocus-conf"><span className="conf-bar"><span style={{ width: `${prop.confidence * 100}%` }} /></span>{Math.round(prop.confidence * 100)}% confidence</span>
          <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--text-muted)' }}>generated {prop.generated}</span>
        </div>
        <h1 className="pfocus-title">{prop.title}</h1>
        {mtg && (
          <div className="pfocus-src" onClick={() => navigate('meetings', { meetingId: mtg.id })}>
            <Icon name="graphic_eq" size={13} />
            <span>from</span>
            <strong>{mtg.title}</strong>
            <span style={{ color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>· {mtg.date}</span>
          </div>
        )}
      </div>

      <div className="pfocus-actions">
        <button className="btn primary large"><Icon name="check" size={15}/>Accept proposal</button>
        <button className="btn large"><Icon name="edit" size={15}/>Refine with AI</button>
        <button className="btn ghost large"><Icon name="close" size={15}/>Dismiss</button>
      </div>

      <div className="pfocus-grid">
        <div>
          <div className="pfocus-section">
            <div className="eyebrow">Rationale</div>
            <p className="pfocus-body">{prop.rationale}</p>
          </div>

          {prop.details && (
            <div className="pfocus-section">
              <div className="eyebrow">Details</div>
              <p className="pfocus-body" style={{ whiteSpace: 'pre-wrap' }}>{prop.details}</p>
            </div>
          )}

          {prop.evidence && prop.evidence.length > 0 && (
            <div className="pfocus-section">
              <div className="eyebrow">Evidence</div>
              {prop.evidence.map((e, i) => {
                if (e.kind === 'transcript') {
                  const p = d.personById(e.who);
                  return (
                    <div key={i} className="evidence-row" onClick={() => navigate('meetings', { meetingId: prop.meetingId })}>
                      <Icon name="format_quote" size={14} style={{ color: 'var(--text-muted)', flexShrink: 0, marginTop: 2 }} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: 4 }}>
                          <strong style={{ color: p.accent }}>{p.name}</strong> @ {e.ts}
                        </div>
                        <div style={{ fontSize: 13, color: 'var(--text)', lineHeight: 1.5, fontStyle: 'italic' }}>&ldquo;{e.text}&rdquo;</div>
                      </div>
                    </div>
                  );
                }
                if (e.kind === 'vault') {
                  const doc = d.docById(e.docId);
                  return (
                    <div key={i} className="evidence-row" onClick={() => navigate('vault', { docId: e.docId })}>
                      <Icon name="description" size={14} style={{ color: 'var(--text-muted)', flexShrink: 0, marginTop: 2 }} />
                      <div style={{ flex: 1 }}>
                        <div style={{ fontSize: 13, color: 'var(--text)' }}>{doc?.name}</div>
                        <div style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 3 }}>{e.note}</div>
                      </div>
                    </div>
                  );
                }
                return null;
              })}
            </div>
          )}
        </div>

        <div>
          <div className="pfocus-section">
            <div className="eyebrow">Status</div>
            <span className="pill" style={{ color: prop.status === 'approved' ? 'var(--primary)' : 'var(--accent-amber)', background: `color-mix(in oklab, ${prop.status === 'approved' ? 'var(--primary)' : 'var(--accent-amber)'} 14%, transparent)` }}>
              <StatusDot status={prop.status === 'approved' ? 'active' : 'triage'} />
              {prop.status === 'approved' ? 'Approved' : 'Pending review'}
            </span>
          </div>

          {relTasks.length > 0 && (
            <div className="pfocus-section">
              <div className="eyebrow">Related tasks</div>
              {relTasks.map((t) => (
                <div key={t.id} className="drawer-row" onClick={() => navigate('tasks', { taskId: t.id })}>
                  <StatusDot status={t.status} />
                  <span className="id" style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--primary)' }}>{t.id}</span>
                  <span style={{ flex: 1, fontSize: 12 }}>{t.title}</span>
                  <Icon name="open_in_new" size={13} style={{ color: 'var(--text-muted)' }} />
                </div>
              ))}
            </div>
          )}

          {relDocs.length > 0 && (
            <div className="pfocus-section">
              <div className="eyebrow">Related docs</div>
              {relDocs.map((doc) => (
                <div key={doc.id} className="drawer-row" onClick={() => navigate('vault', { docId: doc.id })}>
                  <Icon name="description" size={14} style={{ color: 'var(--text-dim)' }} />
                  <span style={{ flex: 1, fontSize: 12 }}>{doc.name}</span>
                  <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10.5, color: 'var(--text-muted)' }}>{doc.folder}</span>
                  <Icon name="open_in_new" size={13} style={{ color: 'var(--text-muted)' }} />
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══ Vault ═══
function VaultPage({ navigate, routeState }) {
  const d = window.EpidoteData;
  const [selectedId, setSelectedId] = _useState(routeState.docId || d.docs[0].id);
  const [view, setView] = _useState('doc');

  _useEffect(() => { if (routeState.docId) { setSelectedId(routeState.docId); setView('doc'); } }, [routeState.docId]);

  const folders = {};
  d.docs.forEach((doc) => {
    (folders[doc.folder] ||= []).push(doc);
  });

  const doc = d.docById(selectedId);

  return (
    <div className="vault-wrap">
      <div className="vault-sb">
        {Object.entries(folders).map(([name, docs]) => (
          <div key={name}>
            <div className="vault-folder"><Icon name="folder" size={12}/>{name}</div>
            {docs.map((doc) => (
              <div key={doc.id} className={`vault-file ${selectedId === doc.id ? 'active' : ''}`} onClick={() => setSelectedId(doc.id)}>
                <Icon name="description" size={12} />
                <span>{doc.name}</span>
              </div>
            ))}
          </div>
        ))}
      </div>
      <div className="vault-main">
        <div className="vault-toolbar">
          <span className="crumb"><span style={{ color: 'var(--text-muted)' }}>VAULT / </span><strong>{doc?.folder}</strong></span>
          <div className="vault-view-toggle" style={{ marginLeft: 'auto' }}>
            <button className={view === 'doc' ? 'active' : ''} onClick={() => setView('doc')}>Document</button>
            <button className={view === 'graph' ? 'active' : ''} onClick={() => setView('graph')}>Graph</button>
          </div>
        </div>
        {view === 'doc' && doc && <VaultDoc doc={doc} navigate={navigate} setDoc={setSelectedId} />}
        {view === 'graph' && <VaultGraph selectedId={selectedId} setSelectedId={setSelectedId} navigate={navigate} />}
      </div>
    </div>
  );
}

function VaultDoc({ doc, setDoc }) {
  const d = window.EpidoteData;
  const contents = {
    'doc-embed-arch': { h1: 'Embedding Architecture', body: [
      { kind: 'p', text: 'The RAG pipeline currently uses 1024-token windows with 128-token overlap for the meetings corpus. Retrieval hits are measured against a ground-truth set built from manual tags.' },
      { kind: 'h2', text: 'Current defaults' },
      { kind: 'p', text: 'Window 1024 · Overlap 128 · Embedding model text-embedding-3-large.' },
      { kind: 'h2', text: 'Related' },
      { kind: 'links', targets: ['doc-chunk-bench','doc-caching-rfc'] },
    ]},
    'doc-chunk-bench': { h1: 'Chunking Benchmarks', body: [
      { kind: 'p', text: 'Evaluated window sizes 256 / 512 / 1024 against overlap 0 / 64 / 128. Recall@10 peaks at 512/64 for the meetings corpus, with token budget staying within 18% of the 256 baseline.' },
      { kind: 'h2', text: 'Recommendation' },
      { kind: 'p', text: 'Propose 512/64 as the new default — see [[Embedding Architecture]].' },
    ]},
    'doc-caching-rfc': { h1: 'Caching RFC v2', body: [
      { kind: 'p', text: 'Proposed write-through cache layer with TTL bucketing for high-frequency reads. Targets a 92%+ hit rate on hot keys without blowing the memory ceiling.' },
    ]},
    'doc-migration': { h1: 'Migration Manifesto v1', body: [
      { kind: 'p', text: 'Decouple the Entity Indexing Service from the monolith. Offload to an event-driven model using RabbitMQ.' },
      { kind: 'h2', text: 'Phase 1' },
      { kind: 'p', text: 'Schema mapping (Marcus), POC architecture (Sarah).' },
    ]},
    'doc-q3-roadmap': { h1: 'Q3 Roadmap v0', body: [
      { kind: 'p', text: 'Top-line theme: retrieval quality. TSK-092 is blocker-adjacent. Roadmap re-sequenced so the RAG pipeline cutover lands before the caching rewrite.' },
    ]},
    'doc-pentest': { h1: 'Pentest Q3 Findings', body: [
      { kind: 'p', text: 'Two highs (both on ingress gateway · shared root cause), five mediums. Remediation before the November release.' },
    ]},
  };
  const c = contents[doc.id] || { h1: doc.name, body: [{ kind: 'p', text: '(Draft content.)' }] };

  return (
    <div className="vault-doc">
      <div className="eyebrow" style={{ marginBottom: 8 }}>Updated {doc.updated}</div>
      <h1>{c.h1}</h1>
      {c.body.map((b, i) => {
        if (b.kind === 'h2') return <h2 key={i}>{b.text}</h2>;
        if (b.kind === 'links') return (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {b.targets.map((id) => {
              const t = d.docById(id);
              return <span key={id} className="wikilink" onClick={() => setDoc(id)}>[[{t?.name}]]</span>;
            })}
          </div>
        );
        // p with inline wikilinks
        const parts = b.text.split(/(\[\[[^\]]+\]\])/);
        return (
          <p key={i}>
            {parts.map((part, j) => {
              const m = part.match(/^\[\[([^\]]+)\]\]$/);
              if (!m) return part;
              const target = d.docs.find((x) => x.name === m[1]);
              return (
                <span key={j} className="wikilink" onClick={() => target && setDoc(target.id)}>{m[1]}</span>
              );
            })}
          </p>
        );
      })}
    </div>
  );
}

function VaultGraph({ selectedId, setSelectedId, navigate }) {
  const d = window.EpidoteData;
  const svgRef = _useRef(null);

  // Physics params (user-tunable)
  const [linkDist, setLinkDist] = _useState(() => +(localStorage.getItem('epidote.graph.linkDist') || 90));
  const [linkThick, setLinkThick] = _useState(() => +(localStorage.getItem('epidote.graph.linkThick') || 1));
  const [gravity, setGravity] = _useState(() => +(localStorage.getItem('epidote.graph.gravity') || 0.04));
  const [repulsion, setRepulsion] = _useState(() => +(localStorage.getItem('epidote.graph.repulsion') || 700));
  const [showLabels, setShowLabels] = _useState(() => localStorage.getItem('epidote.graph.labels') !== '0');
  const [filters, setFilters] = _useState({ doc: true, task: true, meeting: true, proposal: true });

  _useEffect(() => { localStorage.setItem('epidote.graph.linkDist', linkDist); }, [linkDist]);
  _useEffect(() => { localStorage.setItem('epidote.graph.linkThick', linkThick); }, [linkThick]);
  _useEffect(() => { localStorage.setItem('epidote.graph.gravity', gravity); }, [gravity]);
  _useEffect(() => { localStorage.setItem('epidote.graph.repulsion', repulsion); }, [repulsion]);
  _useEffect(() => { localStorage.setItem('epidote.graph.labels', showLabels ? '1' : '0'); }, [showLabels]);

  const W = 800, H = 560;

  // Build graph once per data set. Nodes include proposals now.
  const { nodes, edges } = _useMemo(() => {
    const nodes = [
      ...d.docs.map((doc) => ({ id: doc.id, kind: 'doc', label: doc.name })),
      ...d.tasks.map((t) => ({ id: t.id, kind: 'task', label: t.id })),
      ...d.meetings.map((m) => ({ id: m.id, kind: 'meeting', label: m.title })),
      ...d.proposals.map((p) => ({ id: p.id, kind: 'proposal', label: kindShort(p) })),
    ];
    const edges = [];
    // doc ↔ doc (wikilinks)
    d.docs.forEach((doc) => doc.links.forEach((l) => edges.push({ a: doc.id, b: l, w: 'strong' })));
    // task → meeting, task → doc, task → proposal
    d.tasks.forEach((t) => {
      if (t.meetingId) edges.push({ a: t.id, b: t.meetingId, w: 'normal' });
      t.docs.forEach((did) => edges.push({ a: t.id, b: did, w: 'weak' }));
      if (t.proposalId) edges.push({ a: t.id, b: t.proposalId, w: 'normal' });
    });
    // meeting → proposal, meeting → doc (via proposal doc kind)
    d.meetings.forEach((m) => {
      (m.proposalIds || []).forEach((pid) => edges.push({ a: m.id, b: pid, w: 'normal' }));
      (m.docIds || []).forEach((did) => edges.push({ a: m.id, b: did, w: 'weak' }));
    });
    // proposal → doc/task
    d.proposals.forEach((p) => {
      (p.relatedDocs || []).forEach((did) => edges.push({ a: p.id, b: did, w: 'weak' }));
      (p.relatedTasks || []).forEach((tid) => edges.push({ a: p.id, b: tid, w: 'weak' }));
    });
    // dedupe
    const seen = new Set();
    const dedup = edges.filter((e) => {
      const k = e.a < e.b ? `${e.a}|${e.b}` : `${e.b}|${e.a}`;
      if (seen.has(k)) return false; seen.add(k); return true;
    });
    return { nodes, edges: dedup };
  }, []);

  function kindShort(p) {
    if (p.kind === 'solution') return 'Solution';
    if (p.kind === 'task') return 'Task prop.';
    if (p.kind === 'agenda') return 'Agenda';
    if (p.kind === 'summary') return 'Summary';
    if (p.kind === 'doc') return 'Doc prop.';
    return p.kind;
  }

  // Mutable physics state — lives in refs so we don't re-render per frame.
  const stateRef = _useRef(null);
  if (!stateRef.current) {
    stateRef.current = {
      sims: nodes.map((node, i) => ({
        id: node.id,
        kind: node.kind,
        label: node.label,
        x: W / 2 + Math.cos((i / nodes.length) * Math.PI * 2) * 180 + (Math.random() - 0.5) * 20,
        y: H / 2 + Math.sin((i / nodes.length) * Math.PI * 2) * 180 + (Math.random() - 0.5) * 20,
        vx: 0,
        vy: 0,
        pinned: false,
      })),
    };
  }

  // Tick state — used just to force re-renders at ~60fps.
  const [, setTick] = _useState(0);

  _useEffect(() => {
    let raf;
    let lastPerfT = performance.now();
    const step = () => {
      const now = performance.now();
      const dt = Math.min(32, now - lastPerfT) / 16; // normalized to ~60fps units
      lastPerfT = now;

      const sims = stateRef.current.sims;
      const byId = Object.fromEntries(sims.map((s) => [s.id, s]));

      // Repulsion (O(n²) — fine for n<40)
      for (let i = 0; i < sims.length; i++) {
        const a = sims[i];
        for (let j = i + 1; j < sims.length; j++) {
          const b = sims[j];
          let dx = b.x - a.x, dy = b.y - a.y;
          const dist2 = dx * dx + dy * dy + 0.01;
          const dist = Math.sqrt(dist2);
          const force = repulsion / dist2;
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          a.vx -= fx * dt;
          a.vy -= fy * dt;
          b.vx += fx * dt;
          b.vy += fy * dt;
        }
      }

      // Spring (edges)
      edges.forEach((e) => {
        const a = byId[e.a], b = byId[e.b];
        if (!a || !b) return;
        const dx = b.x - a.x, dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) + 0.01;
        const k = e.w === 'strong' ? 0.06 : e.w === 'normal' ? 0.04 : 0.025;
        const diff = (dist - linkDist) * k;
        const fx = (dx / dist) * diff;
        const fy = (dy / dist) * diff;
        a.vx += fx * dt;
        a.vy += fy * dt;
        b.vx -= fx * dt;
        b.vy -= fy * dt;
      });

      // Gravity toward center + damping + integrate
      const cx = W / 2, cy = H / 2;
      for (const s of sims) {
        if (s.pinned) continue;
        s.vx += (cx - s.x) * gravity * 0.01 * dt;
        s.vy += (cy - s.y) * gravity * 0.01 * dt;
        s.vx *= 0.82;
        s.vy *= 0.82;
        s.x += s.vx * dt;
        s.y += s.vy * dt;
      }

      setTick((t) => (t + 1) % 1000000);
      raf = requestAnimationFrame(step);
    };
    raf = requestAnimationFrame(step);
    return () => cancelAnimationFrame(raf);
  }, [linkDist, gravity, repulsion, edges]);

  // Drag support
  const dragRef = _useRef(null);
  const onPointerDown = (e, id) => {
    e.stopPropagation();
    const s = stateRef.current.sims.find((n) => n.id === id);
    if (!s) return;
    s.pinned = true;
    dragRef.current = { id, startX: e.clientX, startY: e.clientY, origX: s.x, origY: s.y };
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
  };
  const onPointerMove = (e) => {
    if (!dragRef.current) return;
    const svg = svgRef.current;
    if (!svg) return;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX; pt.y = e.clientY;
    const ctm = svg.getScreenCTM();
    if (!ctm) return;
    const loc = pt.matrixTransform(ctm.inverse());
    const s = stateRef.current.sims.find((n) => n.id === dragRef.current.id);
    if (s) { s.x = loc.x; s.y = loc.y; s.vx = 0; s.vy = 0; }
  };
  const onPointerUp = () => {
    if (!dragRef.current) return;
    const s = stateRef.current.sims.find((n) => n.id === dragRef.current.id);
    if (s) s.pinned = false;
    dragRef.current = null;
    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
  };

  const kindColor = {
    doc: 'var(--primary)',
    task: 'var(--error)',
    meeting: 'var(--accent-purple)',
    proposal: 'var(--accent-amber)',
  };
  const kindRadius = { doc: 10, task: 8, meeting: 11, proposal: 9 };

  const sims = stateRef.current.sims;
  const visibleSims = sims.filter((s) => filters[s.kind]);
  const visibleIds = new Set(visibleSims.map((s) => s.id));
  const byId = Object.fromEntries(sims.map((s) => [s.id, s]));

  const handleNodeClick = (n) => {
    if (n.kind === 'doc') setSelectedId(n.id);
    else if (n.kind === 'task') navigate('tasks', { taskId: n.id });
    else if (n.kind === 'meeting') navigate('meetings', { meetingId: n.id });
    else if (n.kind === 'proposal') navigate('proposals', { proposalId: n.id });
  };

  return (
    <div className="vault-graph">
      <svg ref={svgRef} width="100%" height="100%" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" style={{ cursor: 'default', userSelect: 'none' }}>
        {edges.map((e, i) => {
          const a = byId[e.a], b = byId[e.b];
          if (!a || !b) return null;
          if (!visibleIds.has(a.id) || !visibleIds.has(b.id)) return null;
          const alpha = { strong: 0.55, normal: 0.32, weak: 0.18 }[e.w];
          const width = linkThick * (e.w === 'strong' ? 1.3 : e.w === 'normal' ? 1 : 0.75);
          return <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="var(--outline)" strokeOpacity={alpha} strokeWidth={width} />;
        })}
        {visibleSims.map((s) => {
          const isSel = s.id === selectedId;
          const r = (kindRadius[s.kind] || 9) * (isSel ? 1.4 : 1);
          return (
            <g key={s.id} onPointerDown={(e) => onPointerDown(e, s.id)} onClick={() => handleNodeClick(s)} style={{ cursor: 'pointer' }}>
              <circle cx={s.x} cy={s.y} r={r + 5} fill={kindColor[s.kind]} opacity={isSel ? 0.22 : 0.08} />
              <circle cx={s.x} cy={s.y} r={r} fill={kindColor[s.kind]} opacity={0.9} stroke={isSel ? 'var(--text)' : 'none'} strokeWidth={isSel ? 1.5 : 0} />
              {showLabels && (
                <text x={s.x} y={s.y + r + 12} fontSize="9.5" textAnchor="middle" fill="var(--text-dim)" fontFamily="var(--font-mono)" style={{ pointerEvents: 'none' }}>
                  {s.label.length > 22 ? s.label.slice(0, 21) + '…' : s.label}
                </text>
              )}
            </g>
          );
        })}
      </svg>

      {/* Legend (top-left) */}
      <div className="graph-legend">
        {[['doc','Documents'],['task','Tasks'],['meeting','Meetings'],['proposal','Proposals']].map(([k, l]) => (
          <button key={k} className={`legend-item ${filters[k] ? 'on' : 'off'}`} onClick={() => setFilters((f) => ({ ...f, [k]: !f[k] }))}>
            <span className="dot" style={{ background: kindColor[k] }} />
            <span>{l}</span>
          </button>
        ))}
      </div>

      {/* Physics controls (bottom-right) */}
      <div className="graph-controls">
        <div className="gc-title">Physics</div>
        <label><span>Link distance</span><input type="range" min="40" max="220" value={linkDist} onChange={(e) => setLinkDist(+e.target.value)} /><span className="val">{linkDist}</span></label>
        <label><span>Link thickness</span><input type="range" min="0.5" max="3" step="0.1" value={linkThick} onChange={(e) => setLinkThick(+e.target.value)} /><span className="val">{linkThick.toFixed(1)}</span></label>
        <label><span>Gravity</span><input type="range" min="0" max="0.2" step="0.005" value={gravity} onChange={(e) => setGravity(+e.target.value)} /><span className="val">{gravity.toFixed(2)}</span></label>
        <label><span>Repulsion</span><input type="range" min="100" max="2000" step="50" value={repulsion} onChange={(e) => setRepulsion(+e.target.value)} /><span className="val">{repulsion}</span></label>
        <label className="gc-toggle"><input type="checkbox" checked={showLabels} onChange={(e) => setShowLabels(e.target.checked)} /><span>Show labels</span></label>
      </div>
    </div>
  );
}

// ═══ Calendar ═══
function CalendarPage({ navigate }) {
  const d = window.EpidoteData;
  // Render April 2026.
  const year = 2026, month = 3; // 0-indexed April
  const first = new Date(year, month, 1);
  const startDay = first.getDay();
  const offset = (startDay + 6) % 7; // Monday-start
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = [];
  for (let i = 0; i < offset; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  while (cells.length % 7 !== 0) cells.push(null);

  const byDate = {};
  d.calendarEvents.forEach((e) => { (byDate[e.date] ||= []).push(e); });

  return (
    <div className="page">
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
        <h1 className="page-h1">April 2026</h1>
        <button className="btn ghost"><Icon name="chevron_left" size={16}/></button>
        <button className="btn ghost"><Icon name="chevron_right" size={16}/></button>
        <span style={{ marginLeft: 'auto', color: 'var(--text-dim)', fontSize: 12, fontFamily: 'var(--font-mono)' }}>Read-only projection · meetings + task deadlines</span>
      </div>
      <div className="cal-grid">
        {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map((d) => <div key={d} className="cal-head">{d}</div>)}
        {cells.map((day, i) => {
          if (!day) return <div key={i} className="cal-cell other" />;
          const dateStr = `2026-04-${String(day).padStart(2,'0')}`;
          const evs = byDate[dateStr] || [];
          const isToday = day === 22;
          return (
            <div key={i} className={`cal-cell ${isToday ? 'today' : ''}`}>
              <div className="num">{day}</div>
              {evs.map((e, j) => (
                <div key={j} className={`cal-event ${e.kind === 'deadline' ? 'deadline' : ''}`} onClick={() => e.meetingId ? navigate('meetings', { meetingId: e.meetingId }) : e.taskId ? navigate('tasks', { taskId: e.taskId }) : null}>
                  {e.time && <span style={{ color: 'var(--text-muted)', marginRight: 4 }}>{e.time}</span>}{e.title}
                </div>
              ))}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ═══ Settings ═══
function SettingsPage() {
  return (
    <div className="page">
      <h1 className="page-h1">Settings</h1>
      <p className="page-sub">Integrations, audio devices, AI model preferences, and account.</p>
      <div className="settings-col" style={{ marginTop: 24 }}>
        {[
          ['Recording input', 'MacBook Pro Microphone', 'Default system audio source'],
          ['AI model', 'epidote-intel-v3', 'Used for summaries, agendas, and proposals'],
          ['Vault location', '~/Documents/Epidote/Vault', 'Local-first storage for your knowledge base'],
          ['Calendar sync', 'Google · antunes@…', '1 connected calendar'],
          ['Integrations', '3 connected', 'GitHub, Linear, Slack'],
          ['Theme', 'System (dark)', 'Use Tweaks to preview variants'],
        ].map(([lbl, val, sub]) => (
          <div key={lbl} className="settings-row">
            <div>
              <div className="lbl">{lbl}</div>
              <div className="sub">{sub}</div>
            </div>
            <div className="val">{val}</div>
            <Icon name="chevron_right" size={16} style={{ color: 'var(--text-muted)', marginLeft: 16 }} />
          </div>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { TodayPage, MeetingsPage, TasksPage, ProposalsPage, VaultPage, CalendarPage, SettingsPage });
